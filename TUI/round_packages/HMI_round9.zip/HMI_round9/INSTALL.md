# Round 9: on-water web graphs, filtered CAN log, TUI EKF display

Three features for use on the water, where you can't upload a log to me.

```
hmi/
  can_recorder.py     NEW - records only the CAN frames the HMI uses
  app.py              EKF + recorder + telemetry + log download route
  can_interface.py    raw-message listener hook (for the recorder)
  hmi_tui.py          EKF strip
  CHANGES.md
templates/
  plot_data.html      live EKF/disagreement/rudder graphs + log link
tests/
  test_can_recorder.py  NEW - 8 tests
```

## 1. Live graphs on the web page (/plot)

Open `http://<pi>:5000/plot`. New this round:

- **EKF trace** on the angles chart, alongside compass / heading / COG / goal.
- **Sensor disagreement** chart: COG−compass, EKF−compass, EKF−COG. This is the
  one to watch when sources diverge — you'll see exactly which sensor is off.
- **Rudder / steering** chart: steering goal (counts), rudder angle, heading
  error.
- **EKF yaw rate + sigma** chart.
- A **status bar** across the top: active source (COG/COMPASS, color-coded),
  live EKF sigma, and the CAN log path + a **Download log** link.

The page auto-connects to the WebSocket; no setup beyond opening it.

## 2. Filtered CAN log (path + download link)

`can_recorder.py` writes a candump-format log containing **only the messages
the HMI actually uses** — about 17% of the bus on your real capture. That's
small enough to share and is exactly what the fusion sees.

- The **path** shows in the status bar on /plot (e.g.
  `logs/used_can-2026-07-25_1530.log`).
- The **Download log** link (or `http://<pi>:5000/used-can-log`) saves the
  current log.

When you get back to shore (or have signal), download it and send it to me —
it replays directly, so I can analyze exactly what you saw on the water.

The log rotates at 20 MB. It keeps address claims too, so the NAME registry
rebuilds on replay.

## 3. TUI EKF numbers

The TUI now shows a one-line EKF strip when the filter is running:

```
EKF  H  98.7  rate +5.4/s  sig 0.7  [2st]  in:CG-  rej 3
```

- **H / rate** — the EKF's heading and yaw-rate outputs
- **sig** — confidence (lower is better; color-coded)
- **bias** — learned yaw-rate bias (3-state only)
- **[2st]** — 2-state or 3-state (3-state appears once a gyro is present)
- **in:CG-** — inputs present: **C**ompass, co**G**, g**Y**ro
- **rej** — yaw-rate rejections so far

## Enabling the EKF on the web server

app.py has `EKF_ENABLED = True` near the top. It runs the EKF on the web
server's CAN interface with speed-weighted COG trust (no hard threshold — it
blends compass-derivative and COG smoothly by speed). Set it False to hide the
EKF traces.

## Also fixed

The `/sw.js` route in app.py had the same unescaped-dot bug the TUI server had
(`r"/sw.js"` matched `/swXjs`). Corrected to `r"/(sw\.js)"`.

## Tests

```bash
python3 -m pytest tests/test_can_recorder.py -v
python3 -m pytest                                   # full: 544 passing
```
