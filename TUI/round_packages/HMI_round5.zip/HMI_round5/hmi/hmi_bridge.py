"""
hmi_bridge.py -- Translates decoded CAN dicts into SystemState updates.

can_interface.process_message returns loosely-shaped dicts. Rather than
rewrite that decoder, this module maps its output keys onto named signals.
Keeping the mapping in one table means that when a PGN decoder changes, or
when the Kalman filter starts publishing fused heading, there is exactly one
place to edit.

The mapping is deliberately tolerant: unknown keys are ignored rather than
raising, because a decoder that grows a new field should not crash the HMI.
"""

from __future__ import annotations

import logging
import math
from typing import Optional

from hmi_heading import HeadingMonitor
from hmi_state import SystemState

logger = logging.getLogger("bridge")

# Minimum SOG (mph) for COG to be a usable heading. Below this the boat has no
# steerage way, COG degrades to GPS noise, and -- on this hull -- there is no
# trustworthy heading at all, so the autopilot centers and waits for motion.
# This is the single knob that governs the "wait for motion" behaviour.
COG_MIN_SPEED_MPH = 1.6

# decoded-dict key -> signal name
KEY_TO_SIGNAL = {
    "steering_angle": "steering_angle",
    "steering_goal": "steering_goal",
    "rudder_angle": "rudder_angle",
    "rudder_value": "rudder_value",
    "rpm": "rpm",
    "lat": "lat",
    "lon": "lon",
    "SOG": "sog",
    "COG": "cog",
    "compass_heading": "compass_heading",
    "compass": "compass_heading",
    "pitch": "pitch",
    "roll": "roll",
    "compass_offset": "compass_offset",
    # Heading node (sensor_node/PROTOCOL.md)
    "node_heading": "node_heading",
    "node_heading_sigma": "node_heading_sigma",
    "node_yaw_rate": "node_yaw_rate",
    "node_pitch": "pitch",   # the node finally gives us real pitch/roll
    "node_roll": "roll",
    "node_mag_cal": "node_mag_cal",
    "node_fix_type": "node_fix_type",
    "node_num_sats": "node_num_sats",
}

# Watched IDs and how long each may be silent before it is called stale.
# Values are ~3x nominal publish interval.
WATCHED = {
    0x18F01D21: ("steering", 1.5),
    0x19F10D13: ("rudder", 2.0),
    0x09F8021C: ("gps_cog_sog", 1.5),
    0x09F8011C: ("gps_position", 1.0),
    0x18FEE81C: ("gps_vehicle_dir", 3.5),
    0x0CF00400: ("engine", 1.0),
    0x09F112F8: ("compass_F8", 1.0),
    0x18FF50E0: ("autopilot_status", 1.0),
    # Heading node: 10 Hz heading + attitude, 1 Hz health. Allow ~5x the
    # nominal interval before calling them stale.
    0x18FF80E1: ("heading_node", 0.5),
    0x18FF81E1: ("node_attitude", 0.5),
    0x18FF82E1: ("node_health", 5.0),
}


class Bridge:
    def __init__(self, state: SystemState, monitor: HeadingMonitor,
                 registry=None) -> None:
        self.state = state
        self.monitor = monitor
        # NAME-bound heading source registry. Defaults to the profiles in
        # heading_sources.py. The calibration tool and the main TUI can toggle
        # sources on this object at runtime.
        from heading_sources import HeadingSourceRegistry
        self.heading_registry = registry or HeadingSourceRegistry()
        # Latest heading per source address, so derive_fused can pick the
        # registry's preferred source rather than whatever arrived last.
        # {sa: (value, timestamp)}
        self._heading_by_sa: dict = {}
        for can_id, (name, stale) in WATCHED.items():
            state.register_source(can_id, name, stale)

    def on_decoded(self, data: dict) -> None:
        """
        Callback registered with CANinterface.add_listener.

        Wrapped in a broad try because this runs on the CAN read path; a
        malformed frame producing an unexpected dict shape must not take
        down the reader loop. The exception is logged with its traceback so
        it is still visible rather than silently eaten.
        """
        try:
            self._on_decoded(data)
        except Exception:
            logger.exception("bridge failed on payload: %r", data)
            self.state.log_event("WARN", "decode bridge error (see log)")

    def _on_decoded(self, data: dict) -> None:
        st = self.state

        # Timeout notifications from the old interface come through here too.
        if data.get("timeout"):
            return

        for key, value in data.items():
            sig = KEY_TO_SIGNAL.get(key)
            if sig is not None and value is not None:
                st.set_signal(sig, value)

        # Heading quality inputs. Route per-source heading (tagged with its
        # source address) into per-SA storage so derive_fused can honor the
        # NAME-bound source priority. The wall compass and the 24xd both send
        # heading; without this, whichever arrived last would win.
        if data.get("heading_sa") is not None and data.get("heading_value") is not None:
            import time as _t
            sa = int(data["heading_sa"])
            self._heading_by_sa[sa] = (float(data["heading_value"]), _t.time())
            # Only feed the monitor from the registry's preferred source, so
            # the sigma/noise stats reflect the source we actually steer by.
            best = self.heading_registry.best_source()
            if best is None or best.source_address == sa:
                self.monitor.add_heading(float(data["heading_value"]))
        elif "compass_heading" in data and data["compass_heading"] is not None:
            self.monitor.add_heading(float(data["compass_heading"]))
        elif "compass" in data and data["compass"] is not None:
            self.monitor.add_heading(float(data["compass"]))

        if data.get("pitch") is not None:
            self.monitor.add_pitch(float(data["pitch"]))
        if data.get("roll") is not None:
            self.monitor.add_roll(float(data["roll"]))

        # Fused heading: until the Kalman filter is wired in, fall back to
        # compass when it is fresh, else COG. Replace this block with the
        # filter output and the rest of the HMI needs no changes.
        if "fused_heading" in data and data["fused_heading"] is not None:
            st.set_signal("fused_heading", float(data["fused_heading"]))
        if "heading_sigma" in data and data["heading_sigma"] is not None:
            self.monitor.set_filter_sigma(float(data["heading_sigma"]))
        if "yaw_rate" in data and data["yaw_rate"] is not None:
            st.set_signal("yaw_rate", float(data["yaw_rate"]))

        # Control state echoed from the autopilot status frame
        if "autopilot_engaged" in data:
            st.autopilot_engaged = bool(data["autopilot_engaged"])
        if "servo_enabled" in data:
            st.servo_enabled = bool(data["servo_enabled"])
        if "left_turn" in data:
            st.left_turn = bool(data["left_turn"])
        if "right_turn" in data:
            st.right_turn = bool(data["right_turn"])
        if "heading_error" in data and data["heading_error"] is not None:
            st.heading_error = float(data["heading_error"])

        # COG accept/reject accounting, a proxy until the filter reports it
        if "COG" in data:
            sog = st.signal_value("sog")
            if sog is not None and sog < 1.6:
                st.cog_rejected += 1
            else:
                st.cog_accepted += 1

    def derive_fused(self) -> None:
        """
        Periodic fallback fusion. Called on the health tick.

        Priority order:
          1. heading node fused output (gyro + GPS + calibrated mag) -- valid
             at any speed, so it lifts the wait-for-motion restriction
          2. COG when moving (COG-primary, for the boat's own GPS)
          3. compass as a brief bridge if COG drops at speed (NOT trusted)
          4. nothing usable -> None, center rudder and wait

        Levels 2-4 are the COG-primary logic that applies when the heading node
        is absent or invalid. The node is preferred because it fuses a rate
        gyro and a calibrated magnetometer with GPS course, giving a heading at
        rest that COG alone cannot. If the node dies, the HMI degrades cleanly
        to the COG-primary behavior below.

        The Kalman filter, if added, would live on the node and feed level 1.
        """
        st = self.state
        node = st.get_signal("node_heading")
        comp = st.get_signal("compass_heading")
        cog = st.get_signal("cog")
        sog = st.signal_value("sog") or 0.0

        # Priority 1: the heading node's fused output. It blends gyro + GPS
        # course + a calibrated magnetometer, so when it is valid it gives a
        # trustworthy heading at ANY speed -- including at rest, which COG
        # cannot do. This is the whole reason the node exists: it lifts the
        # "wait for motion" restriction that the stuck compass forced on us.
        node_ok = node is not None and node.is_valid()
        if node_ok:
            st.set_signal("fused_heading", node.value, node.last_rx)
            st.heading_source = "NODE"
            # A valid node heading is a lock regardless of boat speed, so the
            # autopilot may steer even at rest (e.g. holding station).
            st.cog_lock = True
            # Feed the node's own sigma to the monitor so the engage gate uses
            # the filter's confidence rather than raw compass scatter.
            ns = st.signal_value("node_heading_sigma")
            if ns is not None:
                self.monitor.set_filter_sigma(ns)
            return

        cog_ok = cog is not None and cog.is_valid() and sog >= COG_MIN_SPEED_MPH
        comp_ok = comp is not None and comp.is_valid()

        # Priority 2: the registry's preferred heading sources, best first.
        # Iterating (rather than taking only the single best) means a stale
        # primary falls back to the next enabled source -- so if the 24xd drops
        # out, the wall compass covers it before we fall through to COG. To
        # change which wins, edit heading_sources.py or toggle enabled at
        # runtime. A good magnetic heading is trustworthy at any speed, so it
        # is a lock like the node. The uncalibrated 24xd sends the
        # data-not-available sentinel, which the decoder rejects, so it simply
        # will not appear here until calibrated -- the fusion "just works" once
        # calibration enables it.
        import time as _t
        now = _t.time()
        for src in self.heading_registry.enabled_sources_by_priority():
            if src.source_address is None:
                continue
            entry = self._heading_by_sa.get(src.source_address)
            if entry is None:
                continue
            value, ts = entry
            if now - ts <= 1.0:   # ~10 Hz heading, allow ~1 s
                st.set_signal("fused_heading", value, ts)
                st.heading_source = src.label.upper().replace(" ", "_")
                st.cog_lock = True
                return

        if cog_ok:
            st.set_signal("fused_heading", cog.value, cog.last_rx)
            st.heading_source = "COG"
            st.cog_lock = True
        elif comp_ok and sog >= COG_MIN_SPEED_MPH:
            # Moving, but COG dropped out. Compass is weak on this boat, so
            # this is a bridge for a few frames, not a heading to trust for
            # long. Marked distinctly so the autopilot can hold rather than
            # chase it.
            st.set_signal("fused_heading", comp.value, comp.last_rx)
            st.heading_source = "COMPASS"
            st.cog_lock = False
        else:
            # No steerage way, or no usable heading. Clear fused so the
            # autopilot centers and waits.
            st.set_signal("fused_heading", None)
            st.heading_source = "NONE"
            st.cog_lock = False
