# Round 5: GPS 24xd, NAME-bound heading sources, calibration TUI

Drop these into your HMI folder.

```
hmi/
  heading_sources.py        NEW - NAME-bound heading source registry
  calibrate_compass_tui.py  NEW - on-water 24xd calibration helper
  can_interface.py          375-deg sentinel fix, multi-source heading decode
  hmi_bridge.py             registry-driven source selection in derive_fused
  app_tui.py                manual step -> counts; feeds claims to registry
  CHANGES.md
tests/
  test_heading_sources.py   NEW - 17 tests
  test_manual_control.py     updated for counts
```

`heading_sources.py` and `calibrate_compass_tui.py` go next to the other hmi
modules.

## What changed and why

**The 375-degree heading is fixed.** Your uncalibrated 24xd was sending the
NMEA "data not available" sentinel, which the old decoder turned into 375.5 deg
-- that was driving the `sig 61 / HEADING_NOISE` faults you saw. Rejected now.

**Manual steps are now 10 encoder counts** (were mislabeled as 2 degrees). The
steering goal is in counts, as your screenshots show (1475 = center).

**Heading sources are bound by NAME, not address.** The registry knows your two
heading devices by their stable identities:
  - GPS 24xd (identity 1602535) -- priority 1, starts DISABLED
  - Wall compass (identity 1039212) -- priority 2, enabled

Until the 24xd is calibrated, the wall compass drives heading. Once you
calibrate and enable the 24xd, it takes over automatically -- at any address,
and it works even at rest.

## Calibrating the 24xd (on the water)

1. Run the calibration tool on the boat:
   ```
   python3 calibrate_compass_tui.py --channel can0 --bitrate 250000
   ```
   (Dry-run first if you like: `--replay logs/somefile.log`.)

2. If the device is not found, press **A** to request address claims.

3. Follow the on-screen steps -- they mirror the 24xd manual's basic
   calibration:
   - Drive to calm, open water.
   - Two slow, tight circles within 3 minutes (heading disappears when it
     detects them).
   - Continue ~1.5 more rotations until heading reappears.
   - Straighten and drive a straight line at **>= 4 mph** until heading
     settles.

4. When the tool shows **DONE**, press **E** to enable the 24xd.

5. Restart the HMI. The 24xd is now your primary heading source.

The tool shows live heading, speed, and GPS fix so you know when you have the
4 mph the alignment step needs.

## Changing or turning off sources

Everything about source selection lives in `heading_sources.py`:

- To change which source is primary: edit the `priority` numbers in
  `DEFAULT_PROFILES`.
- To turn a source off: set `enabled=False` (or call
  `registry.set_enabled(identity, False)` at runtime).
- To add the Teensy heading node later: uncomment its profile block and fill in
  its NAME identity.

The fusion (`derive_fused` in `hmi_bridge.py`) just consumes the registry's
choice, so you never edit fusion logic to change sources -- that is the whole
point of the split.

## Tests

```bash
python3 -m pytest tests/test_heading_sources.py -v   # the new suite
python3 -m pytest                                     # full: 501 passing
```

## Note on the calibration enable

When you press E, the tool flips the 24xd's `enabled` flag to True in
`heading_sources.py` on disk, so the setting sticks across restarts. If you run
the calibration tool and the HMI in the same process against a shared registry
(not the default setup), you would call `registry.set_enabled(1602535, True)`
directly instead -- there is a comment marking where.
