# Round 7: heading EKF using the compass derivative

Your idea — a biased compass still has an accurate derivative — is correct, and
now implemented. Drop these into your HMI folder.

```
hmi/
  heading_ekf.py     NEW - 2-state and 3-state heading EKF
  compare_ekf.py     NEW - generates the comparison plot
  hmi_bridge.py      step_ekf(), EKF as a source in derive_fused
  app_tui.py         calls step_ekf() in the health tick
  CHANGES.md
tests/
  test_heading_ekf.py  NEW - 13 tests
```

## Your idea, confirmed — with one caveat

A constant compass bias (declination, hard-iron) differentiates away: a real
10° yaw still moves the compass ~10°. So the compass yaw RATE is trustworthy
even when the heading isn't. That is exactly what the EKF uses.

The caveat: **soft-iron** doesn't just bias the compass, it SCALES the
derivative — a real 10° turn can read 8° or 13° depending on heading. So the
compass yaw rate is a good input *after* the 24xd's soft-iron calibration and
*with* the round-6 yaw-rate limiter gating electrical spikes. You already have
both.

## Which filter — the data decided

`compare_ekf.py` runs both variants against a realistic synthetic scenario
(compass +32° bias, 1.15× soft-iron scale, spikes; noisy COG). RMS error vs the
true track:

| Method | RMS error |
|--------|-----------|
| Priority chain (round 6) | 2.53° |
| **EKF 2-state** | **2.33°** ← best with compass only |
| EKF 3-state (no gyro) | 2.88° ← worse |
| EKF 3-state (with gyro) | **0.77°** ← best, once a gyro exists |

The 3-state's learned bias is **unobservable with only a compass derivative** —
the extra state just adds noise. But add an independent gyro (the 24xd's
attitude output, or the Teensy node) and it makes the bias observable, and the
3-state wins decisively.

**The bridge picks automatically:** 2-state normally, 3-state when
`node_yaw_rate` is present.

Look at `ekf_comparison.png` — panel 3 shows the yaw rate tracking real turns
smoothly (your idea working), panel 4 shows the 3-state learning the scale error
when a gyro is present.

## It runs alongside — it cannot break the chain

The EKF is a NEW source, not a replacement. It's **off by default**. When on, it
feeds `fused_heading` only while its sigma is low (< 15°); if it ever diverges,
`derive_fused` falls straight through to the round-6 priority chain. So turning
it on is safe.

To enable:
```python
bridge.use_ekf = True   # in your startup, or add a TUI toggle
```

## Recommendation

Run the **2-state now** (compass derivative + COG). Once the 24xd is calibrated
and you're decoding its attitude yaw rate, switch to the **3-state** — that's
when your idea pays off most, because the gyro lets the filter learn and
subtract the compass's residual scale error online, live.

## Tests

```bash
python3 -m pytest tests/test_heading_ekf.py -v
python3 -m pytest                                  # full: 531 passing
python3 compare_ekf.py                             # regenerate the plot
```
