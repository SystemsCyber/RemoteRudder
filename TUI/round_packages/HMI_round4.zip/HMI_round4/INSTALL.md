# Round 4: address claims and source identity

Drop these into your HMI folder.

```
hmi/
  j1939_name.py       NEW - address-claim (NAME) decoding + mfg lookup
  can_interface.py    (unchanged this round; included for completeness)
  hmi_bridge.py       source renames (compass_F8, gps_vehicle_dir)
  hmi_state.py        source table: DATA column + claim storage
  hmi_tui.py          8-column table, REQ ADDR button, 'a' key
  app_tui.py          address-claim decode in read loop, request command
  CHANGES.md
tests/
  test_address_claims.py   NEW - 23 tests
  test_canlink.py          updated for the compass_F8 rename
  test_regression.py       updated for the rename
  test_tui_render.py       updated (stale-source test)
  fixtures/stationary_south.log   NEW - real claims + both heading sources
```

`j1939_name.py` goes next to the other hmi modules (same directory).

## What this gives you

The source table now shows who each node actually is. Run it, and the three
Garmin GPS sources (address 0x1C) show "Garmin / 328706". Press REQ ADDR (or
the `a` key, or the web button) and every node re-announces, filling in the
identity of nodes that do not claim on their own -- including your compass on
address 0xF8.

## The compass finding

Your stationary-south logs actually exonerate the Garmin compass: source 0xF8
reads a steady ~170 deg (south) the whole time. The "bounce to 30 deg" was
fused_heading switching between the good compass (0xF8) and the stale GPS
course (0x1C, which reads ~60 deg garbage when the boat is not moving). The
new table makes that switch visible -- you can watch which source is feeding
the fused value.

## Two things to know on the water

1. **Identity columns fill in after REQ ADDR.** The compass and any non-Garmin
   nodes only claim on request. Until you press it, their MFG/FUNCTION columns
   are blank (not wrong -- blank).

2. **The 8-column table needs a wide terminal (>=136 cols).** Your 140-col
   touchscreen shows the full table; anything narrower falls back to the
   compact 6-column view automatically.

## Keys / buttons added

- `a` key or REQ ADDR button: request address claims from all nodes

## Running the tests

```bash
python3 -m pytest tests/test_address_claims.py -v   # the new suite
python3 -m pytest                                    # full: 484 passing
```

## A suggestion worth considering

Now that the table shows which source feeds the fused heading, you may want to
watch it during a real run and decide whether the COG-primary fallback should
ever prefer the Garmin compass (0xF8) over the stale GPS course (0x1C) at low
speed. Right now at rest with no node, fused goes None (center and wait). But
the Garmin compass is trustworthy even at rest -- so if you want heading-hold
at the dock without the sensor node, promoting compass_F8 above the
wait-for-motion rule is a small change to derive_fused. Left as-is for now
since it is a behavior change; flag me if you want it.
