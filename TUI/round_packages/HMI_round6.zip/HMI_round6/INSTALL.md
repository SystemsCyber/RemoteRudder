# Round 6: COG-primary fishing mode, yaw-rate limiting

Drop these into your HMI folder.

```
hmi/
  heading_fusion.py     NEW - yaw-rate limiter + stable-near-last fallback
  hmi_bridge.py         COG-primary at speed, yaw-rate gate in derive_fused
  visualize_fusion.py   NEW - generates the test-case graphs
  CHANGES.md
tests/
  test_heading_fusion.py  NEW - 17 tests
```

## What you asked for, and what it does

**1. COG-primary at speed (fishing).** CONFIRMED and now implemented. There are
three speed bands in `derive_fused`:

  - below 1.6 mph (COG_MIN): no usable heading, center and wait
  - 1.6 to 3.0 mph: magnetic heading primary (low-speed COG is noise)
  - at/above 3.0 mph (COG_PRIMARY_SPEED_MPH): **COG primary** -- holds the
    TRACK straight so the lines trail off the transom, even when the boat crabs
    in a crosswind

To tune: change `COG_PRIMARY_SPEED_MPH` in hmi_bridge.py. Lower it to hold
track sooner; raise it above cruising speed to always prefer magnetic heading.

**2. Yaw-rate limiting.** Any heading change faster than 45 deg/s is discarded
as bad data, and the controller holds its last good heading. I measured your
logs to set this: real turns top out at ~41 deg/s, while COG jitters to
hundreds of deg/s (12% of COG samples jump >45 deg/s even at planing speed).
So 45 deg/s catches the garbage without clipping a real sharp turn. Tune via
`YAW_RATE_MAX_DPS` in heading_fusion.py.

**3. Stable-near-last fallback.** When sources disagree, the fusion drops
impossible jumps, then picks the source closest to the last good heading that
is also steady. A single glitching sensor can't pull the controller off track.

A subtlety worth knowing: a deliberate source SWITCH (e.g. COG dropping out and
the compass taking over, then COG returning) is treated as a handoff, not a
glitch -- so the yaw-rate limit never blocks a legitimate source change. The
limit only guards jumps within one source's stream.

## The graphs

Run `python3 visualize_fusion.py` to regenerate them (needs matplotlib). Two
figures land in the outputs folder:

  - **fusion_test_cases.png**: the fishing crosswind case (COG holds the track
    while the boat crabs 12 deg), the yaw-rate rejections marked with red X's,
    and a panel showing raw COG spiking to 100s of deg/s while the fused output
    stays under 45.
  - **fusion_sensor_disagreement.png**: three sources with one glitching for
    ~15 s; the fused output ignores the glitch and stays on the stable sources.

The synthetic signals are tuned to your measured noise, so the scatter is
realistic. Look at these to confirm the noise behavior makes sense before you
trust it on the water.

## About your calibration question

I predicted the 24xd's behavior in these graphs (clean magnetic heading, small
noise). When you calibrate it and send a real log, I can replace the synthetic
24xd trace with its actual signal and re-check the noise -- and tune the
yaw-rate limit and the fishing threshold against real 24xd + COG timing rather
than my estimates.

## Tests

```bash
python3 -m pytest tests/test_heading_fusion.py -v
python3 -m pytest                                   # full: 518 passing
```
