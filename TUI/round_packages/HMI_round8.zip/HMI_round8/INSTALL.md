# Round 8: COG-primary at 4 mph, with hysteresis

```
hmi/
  hmi_bridge.py           threshold 4 mph + hysteresis dead-band
  CHANGES.md
tests/
  test_heading_fusion.py  + 5 hysteresis tests
```

## What changed

**Threshold raised to 4 mph.** COG becomes primary at 4 mph instead of 3, so
your boat at idle (which often exceeds 3 mph) stays on the magnetic source and
only hands off to COG once genuinely underway. This also matches the 24xd's own
4 mph heading-alignment threshold.

**Hysteresis added.** Just moving the line to 4 mph would still chatter if the
boat hovers right at it. So COG-primary now engages at 4 mph but does not drop
back to magnetic until below 3 mph -- a 1 mph dead-band. A boat wobbling near
the threshold gets at most one transition instead of flipping every sample.

To tune: `COG_PRIMARY_SPEED_MPH` (engage) and `COG_PRIMARY_DROP_MPH` (drop) at
the top of hmi_bridge.py. Widen the band by lowering the drop value.

## Tests

```bash
python3 -m pytest tests/test_heading_fusion.py -v   # includes hysteresis
python3 -m pytest                                    # full: 536 passing
```
