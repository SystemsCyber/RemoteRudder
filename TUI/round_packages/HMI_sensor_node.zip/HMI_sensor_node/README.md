# Heading node integration

A Teensy-based sensor node (NEO-M9N GPS + MPU-9250 IMU) that runs edge fusion
and broadcasts a finished heading the HMI steers by. This is the fix for the
root problem behind everything else: the boat's built-in compass is stuck, so
the HMI had to run COG-only, which dies below ~1.6 mph. A calibrated
magnetometer plus GPS course plus a rate gyro gives a trustworthy heading at
any speed.

## What's here

```
sensor_node/
  PROTOCOL.md        the CAN message contract (three IDs, byte layouts)
  heading_node.ino   the Teensy sketch (edge fusion + CAN broadcast + mag cal)
hmi/
  can_interface.py   decoder with the three new message branches
  hmi_bridge.py      fusion with the node as top-priority heading source
  test_heading_node.py   23 tests: decode, priority, degradation
```

The two HMI files replace the ones in your tree. `test_heading_node.py` goes in
`tests/`. Everything else in the HMI is unchanged.

## Design decisions (your choices)

- **Edge fusion on the Teensy.** The filter runs on the node, next to the IMU
  where the timing is clean. The node emits a finished heading; the HMI
  consumes it directly.
- **Proprietary CAN IDs** (0x18FF80E1/81E1/82E1), verified collision-free
  against your July 2026 captures. Source address 0xE1 is unused on your bus.

## The priority chain

`derive_fused` now tries, in order:

1. **heading node** (valid) -- trusted at any speed, including at rest
2. **COG** (moving, boat's own GPS) -- the COG-primary logic from last round
3. **compass** (brief bridge if COG drops at speed) -- not trusted
4. **nothing** -> center rudder and wait

A dead or invalid node falls straight through to level 2, so it degrades
exactly to the current behavior. The node adds capability without adding a
failure mode -- verified by `test_stale_node_falls_back_to_cog` and
`test_stale_node_at_rest_gives_no_heading`.

## Before this works on the water

**The sketch is a scaffold with real fusion math but stubbed sensor reads.**
Three things need doing:

1. **Wire the sensor drivers.** `readIMU()` and `readGPS()` are stubs with the
   right shape. Connect them to your MPU-9250 and u-blox libraries (SparkFun
   u-blox GNSS and bolderflight MPU9250 are the usual picks). Each read is
   isolated so this is a localized change.

2. **Calibrate the magnetometer.** This is the crux -- an uncalibrated MPU-9250
   near an engine is no better than the compass we are working around.
   `calibrateMag()` is included: run it once on the boat, engine running,
   rotating through all orientations for 60 s, then paste the printed
   offset/scale into `magCal` and set `valid = true`. Until you do, the node
   leans entirely on GPS course and cannot give a heading at rest.

3. **Set your magnetic declination.** `MAG_DECLINATION_DEG` is 8.0 (Fort
   Collins). Adjust from https://www.ngdc.noaa.gov/geomag/ for your water.

Also check the **yaw-rate sign** (positive = starboard turn) and the CAN pins
(the sketch assumes CAN1 on the Teensy 4.0 per your gateway schematic).

## Wiring, from the Rev 2 schematic

You sent the "Secure Gateway or CAN Conditioner" Rev 2 (2020). The heading node
is not a separate board -- it is this gateway populated with its GPS (BRD1) and
Accelerometer (BRD2) daughter boards. The sketch pins now match it:

| Function | Pins | Bus |
|----------|------|-----|
| CAN1 (vehicle transceiver U5) | CAN1TX=D22, CAN1RX=D23 | broadcast bus |
| MPU-9250 | SDA1=D17, SCL1=D16, own 4.7k pullups, INT line | Wire1 (I2C1) |
| NEO-M9N | GPS_TX/GPS_RX on Serial5 (D20/D21), PPS, !RESET, INT | UART |

The M9N is also wired to the primary I2C (shared with the ATECC608A crypto),
but the sketch uses its UART instead to avoid contending with the crypto chip
on that bus.

## The hard-iron problem is on the board, not just the boat

This matters enough to call out. The MPU-9250 shares the PCB with two CAN
transceivers, the OKI-78SR switching DC/DC converter, and four LEDs -- several
magnetic sources within inches of the magnetometer, some of them switching
under load. That means:

- **Calibrate in normal operating state.** Powered from the boat, CAN active,
  LEDs in their usual condition. A bench calibration with different power/LED
  state bakes in the wrong offset.
- **Expect a messier calibration** than a standalone magnetometer gives.
- **If it stays poor, move the sensor.** Relocating the M9N/MPU daughter boards
  onto a standoff or short mast, away from the converter and transceivers, is
  the standard fix and beats any software correction. The `mag_cal` field in
  the health message (0-3) tells you whether calibration succeeded -- watch it.

This board layout is very likely part of why the original compass reads were
bad in the first place.

## Testing

The HMI side is fully tested against synthetic node frames built to
PROTOCOL.md:

```bash
python3 -m pytest tests/test_heading_node.py -v
```

23 tests: message decode with correct scaling/offsets, node-beats-COG priority
at rest and at speed, sigma feeding the engage gate, and clean degradation when
the node goes stale or invalid. The full suite is 461 passing.

The sketch itself is not unit-tested (it is Arduino/C++ on hardware), but its
byte layout is validated indirectly: the Python tests build frames exactly as
PROTOCOL.md specifies and the decoder reads them back correctly, so if the
sketch follows the protocol the two agree.

## A note on the health message

`0x18FF82E1` carries `mag_cal` (0-3). If that sits at 0 or 1 on the water, the
magnetometer calibration did not take and the node is running on GPS course
alone -- which means you are back to the COG-primary behavior with its
low-speed limitation. Watch that field on the first few runs; it is the
canary for whether the whole exercise succeeded.
